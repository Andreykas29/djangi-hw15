from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
# Create your views here.
from account.models import PersonalAccount

def account_main(request): # відображення головної сторінки особистого кабінету

    return render(request, 'account_main.html')


def basket(request): # відображення корзини користувача, видалення товарів
    return render(request, 'basket.html')


def change_password(request): # зміна паролю аккаунту
    return render(request, 'change_password.html')