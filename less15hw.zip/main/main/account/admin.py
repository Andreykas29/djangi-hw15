from django.contrib import admin
from account.models import PersonalAccount
# Register your models here.


class AcoountAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'email', 'last_online')
    list_display_links = ('full_name', )


admin.site.register(PersonalAccount, AcoountAdmin)