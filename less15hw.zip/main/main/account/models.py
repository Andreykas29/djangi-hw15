from django.db import models

# Create your models here.


class PersonalAccount(models.Model):
    full_name = models.CharField(max_length=100)
    balance = models.IntegerField()
    email = models.CharField(max_length=40)
    basket = models.TextField()
    last_online = models.DateTimeField(auto_now_add=True)

