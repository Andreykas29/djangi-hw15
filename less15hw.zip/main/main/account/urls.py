from django.urls import path

from account.views import account_main, basket, change_password

urlpatterns = [
    path('', account_main), # відображення головної сторінки особистого кабінету
    path('basket/', basket), # відображення корзини користувача, видалення товарів
    path('change_password/', change_password) # зміна паролю аккаунту
]