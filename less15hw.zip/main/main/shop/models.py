from django.db import models


# Create your models here.

def upload_location(instance, filename):
    return f'{instance.id}, {filename}'



class Item(models.Model):
    item_names = (('phone', 'phone'),
                  ('watch', 'watch'),
                  ('monitors', 'monitors')
                  )

    title = models.CharField(max_length=50)
    price = models.DecimalField(max_digits=10, decimal_places=0)
    url = models.URLField(max_length=200)
    item = models.CharField(max_length=30, choices=item_names, default= '')
    image = models.ImageField(null=True, blank=True,
                              height_field='height_field',
                              width_field='width_field',
                              upload_to=upload_location)
    height_field = models.IntegerField(default=0)
    width_field = models.IntegerField(default=0)


    def __str__(self):
        return self.title

    def get_urls(self):
        return f'/shop/{self.item}/details/{self.id}'

    def delete_item_urls(self):
        return f'/shop/{self.item}/delete/{self.id}'

    def get_img(self):
        return f'http://127.0.0.1:8000/media/{self.image}'