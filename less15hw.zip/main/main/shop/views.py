from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, HttpRequest, HttpResponseRedirect, Http404
from shop.models import Item
from shop.forms import ItemForm
from django.contrib import messages
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
# Create your views here.


def main_shop(request):

    return render(request, 'main_page_shop.html')


def shop_phones(request):
    phones_queryset = Item.objects.all().filter(item='phone')
    paginator = Paginator(phones_queryset, 2)
    page_request_var = 'page'
    page = request.GET.get(page_request_var)
    try:
        phones_queryset = paginator.page(page)
    except PageNotAnInteger:
        phones_queryset = paginator.page(1)
    except EmptyPage:
        phones_queryset = paginator.page(paginator.num_pages)
    context = {
        'phone_list': phones_queryset,
        'page_request_var': page_request_var
    }
    return render(request, 'shop_phones.html', context)


def shop_watch(request):
    watches_queryset = Item.objects.all().filter(item='watch')
    paginator = Paginator(watches_queryset, 2)
    page_request_var = 'page'
    page = request.GET.get(page_request_var)
    try:
        watches_queryset = paginator.page(page)
    except PageNotAnInteger:
        watches_queryset = paginator.page(1)
    except EmptyPage:
        watches_queryset = paginator.page(paginator.num_pages)
    context = {
        'watch_list': watches_queryset,
        'page_request_var': page_request_var
    }
    return render(request, 'shop_watch.html', context)


def shop_monitors(request):
    monitors_queryset = Item.objects.all().filter(item='monitors')
    paginator = Paginator(monitors_queryset, 2)
    page_request_var = 'page'
    page = request.GET.get(page_request_var)
    try:
        monitors_queryset = paginator.page(page)
    except PageNotAnInteger:
        monitors_queryset = paginator.page(1)
    except EmptyPage:
        monitors_queryset = paginator.page(paginator.num_pages)
    context = {
        'monitors_list': monitors_queryset,
        'page_request_var': page_request_var
    }
    return render(request, 'shop_monitors.html', context)


def item_details(request, id):
    uniq_item = get_object_or_404(Item, id=id)
    context = {
        'uniq': uniq_item
    }
    return render(request, 'shop_item_details.html', context)


def create_item(request):
    if request.user.username == 'user1' or request.user.is_superuser:
        form = ItemForm(request.POST or None, request.FILES or None)

        if form.is_valid():
            instance = form.save(commit=False)
            instance.save()
            messages.success(request, f'<a href="{instance.get_img()}">Посилання на фото</a>')
            return HttpResponseRedirect(instance.get_urls())
        context = {
            'title': 'create',
            'form': form
        }

        return render(request, 'shop_create.html', context)
    else:
        raise Http404


def update_item(request, id):
    if request.user.username == 'user2' or request.user.is_superuser:
        instance = get_object_or_404(Item,id=id)
        form = ItemForm(request.POST or None,  request.FILES or None, instance=instance)
        if form.is_valid():
            instance = form.save(commit=False)
            instance.save()
            messages.success(request,
                             '<a href="http://127.0.0.1:8000/shop/"><input type="button" value="повернутися на сторінку з категоріями"></a> <br>'
                             '<a href="http://127.0.0.1:8000/shop/create"><input type="button" value="створення нового товару"></a> <br>'
                             '<a href="http://127.0.0.1:8000/shop/"><input type="button" value="головна сторінка проекту"></a>')
            return HttpResponseRedirect(instance.get_urls())
        context = {
            'title': 'item update',
            'form': form
        }
        return render(request, 'shop_create.html',context)
    else:
        raise Http404


def item_delete(request, id=None):
    if request.user.username == 'user3' or request.user.is_superuser:
        instance = get_object_or_404(Item, id=id)
        instance.delete()
        return redirect('shop:main_shop')
    else:
        raise Http404


