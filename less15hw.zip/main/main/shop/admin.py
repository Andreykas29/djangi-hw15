from django.contrib import admin
from shop.models import Item
# Register your models here.


class AdminItem(admin.ModelAdmin):
    list_display = ('title', 'price', 'url')
    list_display_links = ('title', )


# class AdminMonitor(admin.ModelAdmin):
#     list_display = ('title', 'price', 'url')
#     list_display_links = ('title', )
#
#
# class AdminWatch(admin.ModelAdmin):
#     list_display = ('title', 'price', 'url')
#     list_display_links = ('title', )


admin.site.register(Item, AdminItem)
