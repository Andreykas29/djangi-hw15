from django.urls import path

from shop.views import main_shop,item_delete, shop_watch, shop_phones, shop_monitors, item_details, create_item,update_item
app_name='shop'
urlpatterns = [
    path('', main_shop, name='main_shop'),
    path('phones/', shop_phones),
    path('watch/', shop_watch),
    path('monitors/', shop_monitors),
    path('monitors/details/<int:id>', item_details),
    path('phone/details/<int:id>', item_details),
    path('watch/details/<int:id>', item_details),
    path('create', create_item),
    path('monitors/update/<int:id>', update_item),
    path('phone/update/<int:id>', update_item),
    path('watch/update/<int:id>', update_item),
    path('monitors/delete/<int:id>', item_delete),
    path('phone/delete/<int:id>', item_delete),
    path('watch/delete/<int:id>', item_delete),
]