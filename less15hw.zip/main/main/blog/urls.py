from django.urls import path
from blog.views import post_list, post_update, post_create, post_delete, post_detail
app_name = 'blog'
urlpatterns = [
    path('', post_list, name='post_list'),
    path('update/<int:id>/',post_update, name='post_update'),
    path('create/',post_create, name='post_create'),
    path('delete/<int:id>/',post_delete, name='post_delete'),
    path('detail/<int:id>/',post_detail, name='post_detail')

]