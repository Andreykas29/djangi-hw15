from django.contrib import admin
from blog.models import Post


class PostModelAdmin(admin.ModelAdmin):
    list_display = ('title', 'update', 'timestamp', 'topic', )
    list_display_links = ('update', )
    list_editable = ('title', )
    list_filter = ('update', 'timestamp')
    #два додаткових поля
    list_max_show_all = 10 #щоб контролювати, скільки елементів може відображатися на сторінці списку змін
    preserve_filters = False #очистка фільтрів після редагування


admin.site.register(Post, PostModelAdmin)