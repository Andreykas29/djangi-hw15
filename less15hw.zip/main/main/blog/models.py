from django.conf import settings
from django.db import models


def topic_field():
    fields = [
        ('життя', 'життя'),
        ('nature', 'nature'),
        ('animals', 'тварини'),
        ('жарти', 'joke')
    ]
    return fields


def upload_location(instance, filename):
    return f'{instance.id}, {filename}'


class Post(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        default=2,
        on_delete=models.CASCADE
    )
    title = models.CharField(max_length=40)
    image = models.ImageField(upload_to=upload_location, null=True,
                              blank=True,
                              height_field='height_field',
                              width_field='width_field')
    height_field = models.IntegerField(default=0)
    width_field = models.IntegerField(default=0)
    content = models.TextField()
    update = models.DateTimeField(auto_now=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    topic = models.CharField(max_length=10,
                             choices=topic_field(),
                             default='')
    #додаткові 2 поля:
    age_18 = models.BooleanField(null=True) # поле для визначення віку, булеве значення
    phone = models.DecimalField(max_digits=10, decimal_places=2, null=True) # поле для номеру автора

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return f'detail/{self.id}'
